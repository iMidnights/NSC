import Page from "@/components/aboutPage"
import { Metadata } from "next"
export const metadata: Metadata = {
  title: 'About',
}

export default Page